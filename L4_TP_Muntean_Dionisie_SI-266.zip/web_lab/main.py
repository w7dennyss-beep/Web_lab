# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
"""Programul principal: raport JSON și verificarea căilor în CSV."""
import argparse
import csv
from datetime import datetime
from pathlib import Path
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS
from lab_common import BASE_URL, run

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Un get_title definit aici după import ar înlocui numele importat.
# webtools.get_title rămâne accesibil prin numele modulului.


def save_csv(url):
    """Salvează starea căilor indicate în laborator în report.csv."""
    results = webtools.check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
    with Path(__file__).with_name("report.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["path", "status", "checked_at"])
        writer.writeheader()
        for path, status in results.items():
            writer.writerow({"path": path, "status": status, "checked_at": datetime.now().isoformat()})
    return results


def main():
    """Citește URL-ul din terminal și produce ambele rapoarte."""
    parser = argparse.ArgumentParser(description="Raport Python Web")
    parser.add_argument("url", nargs="?", default=BASE_URL)
    args = parser.parse_args()
    webtools.site_report(args.url)
    save_csv(args.url)
    print("Salvat în report.csv")


if __name__ == "__main__":
    run(main)
