# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
"""Funcții reutilizabile pentru laboratorul Python Web."""
import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse
import requests
from lab_common import BASE_URL, TIMEOUT, pause

ECHO_URL = "https://httpbin.org"


DEFAULT_HEADERS = {"User-Agent": "WebLab-Muntean-Dionisie"}
SECURITY_HEADERS = (
    "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
    "X-Content-Type-Options", "Referrer-Policy",
)


def fetch(url: str, timeout: float = TIMEOUT) -> requests.Response:
    """Descarcă un URL cu timeout și o pauză înaintea cererii."""
    pause()
    # Antetul personalizat este verificat doar pe serviciul de test httpbin.
    headers = DEFAULT_HEADERS if isinstance(url, str) and urlparse(url).hostname == "httpbin.org" else None
    return requests.get(url, timeout=timeout, headers=headers)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Extrage titlul HTML prin find și slicing; întoarce șir gol dacă lipsește."""
    start = html.lower().find("<title>")
    if start == -1:
        return ""
    start += len("<title>")
    end = html.lower().find("</title>", start)
    return html[start:end].strip() if end != -1 else ""


def page_exists(url: str) -> bool:
    """Returnează False pentru erori HTTP sau de conexiune."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list) -> dict:
    """Returnează codul fiecărei căi; None indică o eroare de rețea."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(urljoin(base, path))
        except requests.RequestException:
            results[path] = None
    return results


def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează un antet sau valoarea implicită."""
    return fetch(url).headers.get(name, default)


def security_headers(url: str) -> dict:
    """Verifică prezența celor cinci antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADERS}


def score_headers(results: dict) -> str:
    """Exprimă numărul antetelor prezente ca scor x/y."""
    return f"{sum(bool(value) for value in results.values())}/{len(results)}"


def fetch_robots(base: str):
    """Returnează robots.txt sau None dacă lipsește ori nu poate fi citit."""
    try:
        response = fetch(urljoin(base, "/robots.txt"))
        return response.text if response.ok else None
    except requests.RequestException:
        return None


def disallowed_paths(robots_text) -> list:
    """Colectează valorile Disallow nevidе, ignorând comentariile."""
    paths = []
    for line in (robots_text or "").splitlines():
        name, separator, value = line.split("#", 1)[0].partition(":")
        if separator and name.strip().lower() == "disallow" and value.strip():
            paths.append(value.strip())
    return paths


def response_times(*urls) -> dict:
    """Măsoară fiecare descărcare, fără pauza dintre cereri."""
    results = {}
    for url in urls:
        pause()
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        results[url] = time.perf_counter() - start
    return results


def log(message, **details):
    """Afișează mesajul și detaliile primite prin argumente cu nume."""
    print(" | ".join([str(message)] + [f"{key}={value}" for key, value in details.items()]))


def extract_links(html: str) -> list:
    """Extrage href cu expresia regulată cerută, fără duplicate."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links: list, domain: str) -> tuple:
    """Separă legăturile HTTP(S) interne de cele externe."""
    base = domain if "://" in domain else "https://" + domain
    host = urlparse(base).netloc.lower()
    internal, external = [], []
    for link in links:
        url = urljoin(base, link)
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            continue
        target = internal if parsed.netloc.lower() == host else external
        if url not in target:
            target.append(url)
    return internal, external


class ImageFinder(HTMLParser):
    """Colectează sursele imaginilor în ordinea din document."""

    def __init__(self):
        """Inițializează parserul și lista de imagini."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Primește automat fiecare tag de la HTMLParser.feed()."""
        if tag == "img":
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a octeților paginii."""
    return hashlib.sha256(fetch(url).content).hexdigest()


def resolve(hostname: str) -> str:
    """Rezolvă numele domeniului într-o adresă IPv4."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Citește certificatul TLS validat și calculează zilele rămase."""
    pause()
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            expires = secure.getpeercert()["notAfter"]
    return int((ssl.cert_time_to_seconds(expires) - time.time()) // 86400)


def site_report(url: str) -> dict:
    """Colectează, afișează și salvează raportul; consemnează erorile reale."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Folosește un URL complet HTTP sau HTTPS.")
    report = {"url": url, "checked_at": datetime.now(timezone.utc).isoformat()}
    errors = {}
    try:
        response = fetch(url)
        report.update(status=response.status_code, final_url=response.url,
                      title=get_title(response.text))
        headers = {name: name in response.headers for name in SECURITY_HEADERS}
        internal, external = split_links(extract_links(response.text), response.url)
        report.update(security_headers=headers, security_score=score_headers(headers),
                      internal_links=len(internal), external_links=len(external))
    except requests.RequestException as error:
        errors["page"] = str(error)
        report.update(status=None, final_url=None, title=None, security_headers=None,
                      security_score=None, internal_links=None, external_links=None)
    try:
        report["ip"] = resolve(parsed.hostname)
    except OSError as error:
        report["ip"] = None
        errors["dns"] = str(error)
    try:
        redirected = fetch(parsed._replace(scheme="http").geturl())
        report["redirects"] = [{"status": item.status_code, "url": item.url,
                                "location": item.headers.get("Location")}
                               for item in redirected.history]
        report["redirect_final_url"] = redirected.url
    except requests.RequestException as error:
        report["redirects"] = None
        errors["redirects"] = str(error)
    try:
        report["certificate_days_left"] = cert_days_left(parsed.hostname)
    except (OSError, ValueError) as error:
        report["certificate_days_left"] = None
        errors["certificate"] = str(error)
    robots = fetch_robots(url)
    report["disallowed_paths"] = disallowed_paths(robots) if robots is not None else None
    if robots is None:
        errors["robots"] = "robots.txt lipsește sau nu poate fi citit."
    report["errors"] = errors
    output = Path(__file__).with_name("report.json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"=== Raport site: {url} ===")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("Salvat în", output.name)
    return report


if __name__ == "__main__":
    from lab_common import run
    run(lambda: print("Autotest:", get_status(BASE_URL)))
# Blocul de mai sus rulează doar când fișierul este executat direct.
