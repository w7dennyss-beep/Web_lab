# Modulele proiectului sunt în directorul web_lab.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Laborator Python Web — exercițiul 45
# Muntean Dionisie, SI-266

import requests
from webtools import fetch, get_title, security_headers

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 45."""
    from webtools import get_title, security_headers
    print(get_title(fetch(BASE_URL).text))
    print(security_headers(BASE_URL))

if __name__ == "__main__":
    run(main)
