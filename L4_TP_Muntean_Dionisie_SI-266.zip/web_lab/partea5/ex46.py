# Modulele proiectului sunt în directorul web_lab.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Laborator Python Web — exercițiul 46
# Muntean Dionisie, SI-266

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 46."""
    import subprocess
    import sys
    from pathlib import Path
    subprocess.run([sys.executable, str(Path(__file__).resolve().parent.parent / "webtools.py")], check=True)
    import webtools
    print("Importul nu execută autotestul.")

if __name__ == "__main__":
    run(main)
