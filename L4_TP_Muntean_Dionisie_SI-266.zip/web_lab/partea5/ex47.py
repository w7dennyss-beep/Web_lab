# Modulele proiectului sunt în directorul web_lab.
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Laborator Python Web — exercițiul 47
# Muntean Dionisie, SI-266

import requests
from webtools import fetch

BASE_URL = "https://cybercor.org"
TIMEOUT = 10


ECHO_URL = 'https://httpbin.org'

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 47."""
    from webtools import DEFAULT_HEADERS
    print(DEFAULT_HEADERS)
    print(fetch(ECHO_URL + "/headers").json())

if __name__ == "__main__":
    run(main)
