# Laborator Python Web — exercițiul 33
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def response_times(*urls) -> dict:
    """Măsoară fiecare descărcare, fără pauza dintre cereri."""
    results = {}
    for url in urls:
        pause()
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        results[url] = time.perf_counter() - start
    return results

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def main():
    """Demonstrează soluția exercițiului 33."""
    print(response_times(BASE_URL, BASE_URL + "/robots.txt"))

if __name__ == "__main__":
    run(main)
