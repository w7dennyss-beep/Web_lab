# Laborator Python Web — exercițiul 29
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def get_header(url: str, name: str, default: str='lipsește') -> str:
    """Returnează un antet sau valoarea implicită."""
    return fetch(url).headers.get(name, default)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 29."""
    print(get_header(BASE_URL, name="Server"))

if __name__ == "__main__":
    run(main)
