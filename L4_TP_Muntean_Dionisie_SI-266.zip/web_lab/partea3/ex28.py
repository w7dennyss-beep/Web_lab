# Laborator Python Web — exercițiul 28
# Muntean Dionisie, SI-266

import time
import requests
from urllib.parse import urljoin

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def check_paths(base: str, paths: list) -> dict:
    """Returnează codul fiecărei căi; None indică o eroare de rețea."""
    results = {}
    for path in paths:
        try:
            results[path] = get_status(urljoin(base, path))
        except requests.RequestException:
            results[path] = None
    return results

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def get_status(url: str) -> int:
    """Returnează codul de stare HTTP."""
    return fetch(url).status_code

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 28."""
    print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))

if __name__ == "__main__":
    run(main)
