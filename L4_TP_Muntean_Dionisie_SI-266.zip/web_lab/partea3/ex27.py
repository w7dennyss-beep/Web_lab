# Laborator Python Web — exercițiul 27
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def page_exists(url: str) -> bool:
    """Returnează False pentru erori HTTP sau de conexiune."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 27."""
    print(page_exists(BASE_URL))
    print(page_exists("https://this-domain-does-not-exist.invalid"))

if __name__ == "__main__":
    run(main)
