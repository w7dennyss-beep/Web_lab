# Laborator Python Web — exercițiul 32
# Muntean Dionisie, SI-266

import time
import requests
from urllib.parse import urljoin

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def disallowed_paths(robots_text) -> list:
    """Colectează valorile Disallow nevidе, ignorând comentariile."""
    paths = []
    for line in (robots_text or '').splitlines():
        name, separator, value = line.split('#', 1)[0].partition(':')
        if separator and name.strip().lower() == 'disallow' and value.strip():
            paths.append(value.strip())
    return paths

def fetch_robots(base: str):
    """Returnează robots.txt sau None dacă lipsește ori nu poate fi citit."""
    try:
        response = fetch(urljoin(base, '/robots.txt'))
        return response.text if response.ok else None
    except requests.RequestException:
        return None

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 32."""
    print(disallowed_paths(fetch_robots(BASE_URL)))
    print("Pentru None:", disallowed_paths(None))

if __name__ == "__main__":
    run(main)
