# Laborator Python Web — exercițiul 26
# Muntean Dionisie, SI-266

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 26."""
    def get_status(url: str) -> int:
        """Returnează codul HTTP pentru URL-ul primit."""
        return fetch(url).status_code
    try:
        print(get_status(123))
    except requests.RequestException as error:
        print(type(error).__name__, error)

if __name__ == "__main__":
    run(main)
