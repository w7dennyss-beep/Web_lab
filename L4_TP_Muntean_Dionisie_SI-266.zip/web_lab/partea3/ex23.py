# Laborator Python Web — exercițiul 23
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def request(method, url, **kwargs):
    """Trimite o cerere cu timeout și pauză între apeluri."""
    pause()
    kwargs.setdefault('timeout', TIMEOUT)
    return requests.request(method, url, **kwargs)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def main():
    """Demonstrează soluția exercițiului 23."""
    def fetch(url, timeout=10):
        """Descarcă URL-ul cu un timeout configurabil."""
        return request("GET", url, timeout=timeout)
    print(fetch(BASE_URL).status_code)
    print(fetch(BASE_URL, timeout=3).status_code)

if __name__ == "__main__":
    run(main)
