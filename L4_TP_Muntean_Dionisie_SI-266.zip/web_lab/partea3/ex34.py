# Laborator Python Web — exercițiul 34
# Muntean Dionisie, SI-266

import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def log(message, **details):
    """Afișează mesajul și detaliile primite prin argumente cu nume."""
    print(' | '.join([str(message)] + [f'{key}={value}' for key, value in details.items()]))

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 34."""
    log("verificat", url=BASE_URL, status=200)

if __name__ == "__main__":
    run(main)
