# Laborator Python Web — exercițiul 31
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

SECURITY_HEADERS = ('Strict-Transport-Security', 'Content-Security-Policy', 'X-Frame-Options', 'X-Content-Type-Options', 'Referrer-Policy')

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def score_headers(results: dict) -> str:
    """Exprimă numărul antetelor prezente ca scor x/y."""
    return f'{sum((bool(value) for value in results.values()))}/{len(results)}'

def security_headers(url: str) -> dict:
    """Verifică prezența celor cinci antete de securitate."""
    headers = fetch(url).headers
    return {name: name in headers for name in SECURITY_HEADERS}

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 31."""
    print(score_headers(security_headers(BASE_URL)))

if __name__ == "__main__":
    run(main)
