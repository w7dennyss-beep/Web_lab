# Laborator Python Web — exercițiul 22
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 22."""
    def get_status(url):
        """Returnează numai codul HTTP al răspunsului."""
        return fetch(url).status_code
    for path in ["/", "/robots.txt", "/sitemap.xml"]:
        print(path, get_status(BASE_URL + path))

if __name__ == "__main__":
    run(main)
