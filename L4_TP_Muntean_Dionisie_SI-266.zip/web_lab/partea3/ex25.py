# Laborator Python Web — exercițiul 25
# Muntean Dionisie, SI-266

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def get_title(html: str) -> str:
    """Extrage titlul HTML prin find și slicing; întoarce șir gol dacă lipsește."""
    start = html.lower().find('<title>')
    if start == -1:
        return ''
    start += len('<title>')
    end = html.lower().find('</title>', start)
    return html[start:end].strip() if end != -1 else ''

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 25."""
    help(get_title)
    print(get_title("<title> Exemplu </title>"))

if __name__ == "__main__":
    run(main)
