# Laborator Python Web — exercițiul 24
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def get_title(html: str) -> str:
    """Extrage titlul HTML prin find și slicing; întoarce șir gol dacă lipsește."""
    start = html.lower().find('<title>')
    if start == -1:
        return ''
    start += len('<title>')
    end = html.lower().find('</title>', start)
    return html[start:end].strip() if end != -1 else ''

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 24."""
    # get_title analizează HTML-ul; descărcarea se face separat.
    print(get_title(fetch(BASE_URL).text))

if __name__ == "__main__":
    run(main)
