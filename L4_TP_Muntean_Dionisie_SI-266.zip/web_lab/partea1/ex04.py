# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
# Exercițiul 4: numai biblioteca standard.
import urllib.request

ECHO_URL = "https://httpbin.org"

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def main():
    """Descarcă pagina folosind doar urllib.request."""
    import urllib.request
    with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as response:
        print(response.status)
        print(response.read().decode("utf-8")[:200])

if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as error:
        print("Eroare:", error)
