# Laborator Python Web — exercițiul 3
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 3."""
    import requests as rq
    pause()
    print(rq.get(BASE_URL, timeout=TIMEOUT).status_code)

if __name__ == "__main__":
    run(main)
