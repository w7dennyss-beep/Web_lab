# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

# Laborator Python Web — exercițiul 5
# Muntean Dionisie, SI-266



def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 5."""
    import requests
    print(dir(requests))

if __name__ == "__main__":
    run(main)
