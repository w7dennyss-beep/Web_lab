# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
# Exercițiul 1: primul import
# Muntean Dionisie, SI-266
import requests

print(requests.__version__)

import urllib.request

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


# requests este o bibliotecă externă: se instalează cu pip install requests.
# urllib vine împreună cu Python, deci nu trebuie instalat separat.
