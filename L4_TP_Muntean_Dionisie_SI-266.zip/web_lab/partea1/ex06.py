# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
import requests
# Laborator Python Web — exercițiul 6
# Muntean Dionisie, SI-266

import time

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def request(method, url, **kwargs):
    """Trimite o cerere cu timeout și pauză între apeluri."""
    pause()
    kwargs.setdefault('timeout', TIMEOUT)
    return requests.request(method, url, **kwargs)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def main():
    """Demonstrează soluția exercițiului 6."""
    import requests
    help(requests.get)
    # timeout este transmis prin **kwargs; limitează așteptarea conexiunii/citirii.
    print(request("GET", BASE_URL, timeout=TIMEOUT).status_code)

if __name__ == "__main__":
    run(main)
