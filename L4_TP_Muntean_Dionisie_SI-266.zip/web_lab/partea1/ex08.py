# Laborator Python Web — exercițiul 8
# Muntean Dionisie, SI-266

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 8."""
    try:
        import bs4
        print("bs4 este disponibil")
    except ImportError:
        print("Instalați modulul cu: pip install beautifulsoup4")

if __name__ == "__main__":
    run(main)
