# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
import time
# Laborator Python Web — exercițiul 7
# Muntean Dionisie, SI-266

import requests

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 7."""
    import time
    pause()
    start = time.perf_counter()
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    print("Durată totală:", time.perf_counter() - start)
    print("response.elapsed:", response.elapsed.total_seconds())

if __name__ == "__main__":
    run(main)
