# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
"""Generează rapoartele reale și actualizează arhiva pentru predare."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from main import main

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def pregateste():
    """Rulează raportul și arhivează toate fișierele sursă și rezultatele."""
    main()
    directory = Path(__file__).resolve().parent
    archive = directory.parent / "L4_TP_Muntean_Dionisie_SI-266.zip"
    with ZipFile(archive, "w", ZIP_DEFLATED) as output:
        for file in sorted(directory.rglob("*")):
            if file.is_file() and "__pycache__" not in file.parts:
                output.write(file, "web_lab/" + file.relative_to(directory).as_posix())
    print("Arhivă actualizată:", archive)


if __name__ == "__main__":
    pregateste()
