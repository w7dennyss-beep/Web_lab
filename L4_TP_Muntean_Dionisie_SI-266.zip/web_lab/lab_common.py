# Laborator: funcții, metode și importuri pe web
# Student: Muntean Dionisie | Grupa: SI-266
"""Configurarea laboratorului și pauzele dintre cereri."""
import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
_last_request = None


def pause():
    """Păstrează cel puțin o secundă între cereri succesive."""
    global _last_request
    if _last_request is not None:
        time.sleep(max(0, 1 - (time.monotonic() - _last_request)))
    _last_request = time.monotonic()


def request(method, url, **kwargs):
    """Trimite o cerere cu timeout și pauză între apeluri."""
    pause()
    kwargs.setdefault("timeout", TIMEOUT)
    return requests.request(method, url, **kwargs)


def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f"Exercițiul nu a putut fi finalizat: {error}")
