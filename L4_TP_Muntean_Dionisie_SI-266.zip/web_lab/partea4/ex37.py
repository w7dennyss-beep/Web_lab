# Laborator Python Web — exercițiul 37
# Muntean Dionisie, SI-266

import time
import requests
import re

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def extract_links(html: str) -> list:
    """Extrage href cu expresia regulată cerută, fără duplicate."""
    return list(dict.fromkeys(re.findall('href="([^"]+)"', html)))

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 37."""
    print(extract_links(fetch(BASE_URL).text))

if __name__ == "__main__":
    run(main)
