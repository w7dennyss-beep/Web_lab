# Laborator Python Web — exercițiul 42
# Muntean Dionisie, SI-266

import requests
import socket

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def resolve(hostname: str) -> str:
    """Rezolvă numele domeniului într-o adresă IPv4."""
    return socket.gethostbyname(hostname)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 42."""
    print(resolve("cybercor.org"))

if __name__ == "__main__":
    run(main)
