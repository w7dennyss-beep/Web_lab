# Laborator Python Web — exercițiul 41
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 41."""
    def save_headers():
        """Salvează antetele în JSON, le recitește și afișează Content-Type."""
        import json
        from pathlib import Path
        path = Path(__file__).with_name("headers.json")
        with path.open("w", encoding="utf-8") as file:
            json.dump(dict(fetch(BASE_URL).headers), file, indent=2)
        with path.open(encoding="utf-8") as file:
            headers = json.load(file)
        print(next((v for k, v in headers.items() if k.lower() == "content-type"), "lipsește"))
    save_headers()

if __name__ == "__main__":
    run(main)
