# Laborator Python Web — exercițiul 40
# Muntean Dionisie, SI-266

import time
import requests
import hashlib

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a octeților paginii."""
    return hashlib.sha256(fetch(url).content).hexdigest()

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def main():
    """Demonstrează soluția exercițiului 40."""
    first = page_fingerprint(BASE_URL)
    second = page_fingerprint(BASE_URL)
    print(first, second, "Identice:", first == second, sep="\n")

if __name__ == "__main__":
    run(main)
