# Laborator Python Web — exercițiul 35
# Muntean Dionisie, SI-266

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 35."""
    def parse_url():
        """Descompune URL-ul demonstrativ, fără cerere de rețea."""
        from urllib.parse import urlparse
        result = urlparse("https://cybercor.org/path?x=1#top")
        for name in ["scheme", "netloc", "path", "query", "fragment"]:
            print(name, getattr(result, name))
    parse_url()

if __name__ == "__main__":
    run(main)
