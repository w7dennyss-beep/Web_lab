# Laborator Python Web — exercițiul 36
# Muntean Dionisie, SI-266

import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 36."""
    def join_urls():
        """Transformă cele trei legături relative în URL-uri complete."""
        from urllib.parse import urljoin
        for link in ["/about", "contact.html", "../index.html"]:
            print(urljoin(BASE_URL, link))
    join_urls()

if __name__ == "__main__":
    run(main)
