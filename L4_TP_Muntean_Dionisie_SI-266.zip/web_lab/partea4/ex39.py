# Laborator Python Web — exercițiul 39
# Muntean Dionisie, SI-266

import time
import requests
from html.parser import HTMLParser

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

class ImageFinder(HTMLParser):
    """Colectează sursele imaginilor în ordinea din document."""

    def __init__(self):
        """Inițializează parserul și lista de imagini."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Primește automat fiecare tag de la HTMLParser.feed()."""
        if tag == 'img':
            src = dict(attrs).get('src')
            if src is not None:
                self.images.append(src)

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 39."""
    test_html = """<html><body>
    <img src="/logo.png" alt="Logo">
    <IMG SRC="poza.jpg">
    <img alt="imagine fără src">
    <img src="https://cdn.example.com/banner.webp" />
    <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>"""
    finder = ImageFinder()
    finder.feed(test_html)
    print(finder.images)
    assert finder.images == ["/logo.png", "poza.jpg", "https://cdn.example.com/banner.webp"]
    print("Testul a trecut!")
    response = fetch(BASE_URL)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Apariții <img:", response.text.lower().count("<img"))

if __name__ == "__main__":
    run(main)

# HTMLParser.feed() apelează automat handle_starttag() pentru fiecare tag.
# Verifică și sursa paginii în browser, folosind Ctrl+U.
