# Laborator Python Web — exercițiul 38
# Muntean Dionisie, SI-266

import time
import requests
import re
from urllib.parse import urljoin, urlparse

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def extract_links(html: str) -> list:
    """Extrage href cu expresia regulată cerută, fără duplicate."""
    return list(dict.fromkeys(re.findall('href="([^"]+)"', html)))

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def split_links(links: list, domain: str) -> tuple:
    """Separă legăturile HTTP(S) interne de cele externe."""
    base = domain if '://' in domain else 'https://' + domain
    host = urlparse(base).netloc.lower()
    internal, external = ([], [])
    for link in links:
        url = urljoin(base, link)
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https'):
            continue
        target = internal if parsed.netloc.lower() == host else external
        if url not in target:
            target.append(url)
    return (internal, external)

def main():
    """Demonstrează soluția exercițiului 38."""
    internal, external = split_links(extract_links(fetch(BASE_URL).text), BASE_URL)
    print("Interne:", internal)
    print("Externe:", external)

if __name__ == "__main__":
    run(main)
