# Laborator Python Web — exercițiul 43
# Muntean Dionisie, SI-266

import time
import requests
import socket
import ssl

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"


TIMEOUT = 10

def cert_days_left(hostname: str) -> int:
    """Citește certificatul TLS validat și calculează zilele rămase."""
    pause()
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            expires = secure.getpeercert()['notAfter']
    return int((ssl.cert_time_to_seconds(expires) - time.time()) // 86400)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def main():
    """Demonstrează soluția exercițiului 43."""
    print(cert_days_left("cybercor.org"), "zile rămase")

if __name__ == "__main__":
    run(main)
