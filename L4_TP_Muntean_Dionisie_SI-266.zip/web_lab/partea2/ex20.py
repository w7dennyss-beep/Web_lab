# Laborator Python Web — exercițiul 20
# Muntean Dionisie, SI-266

import time
import requests

BASE_URL = "https://cybercor.org"


ECHO_URL = 'https://httpbin.org'

TIMEOUT = 10

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 20."""
    with requests.Session() as session:
        session.headers.update({"User-Agent": "WebLab-Muntean-Dionisie"})
        pause()
        response = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
        response.raise_for_status()
        agent = response.json()["headers"].get("User-Agent")
        print("User-Agent primit:", agent)
        print("Confirmat:", agent == session.headers["User-Agent"])

if __name__ == "__main__":
    run(main)
