# Laborator Python Web — exercițiul 18
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"


BASE_URL = 'https://cybercor.org'

TIMEOUT = 10

def request(method, url, **kwargs):
    """Trimite o cerere cu timeout și pauză între apeluri."""
    pause()
    kwargs.setdefault('timeout', TIMEOUT)
    return requests.request(method, url, **kwargs)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def pause():
    """Așteaptă o secundă înaintea unei cereri."""
    time.sleep(1)

def main():
    """Demonstrează soluția exercițiului 18."""
    head = request("HEAD", BASE_URL)
    get = request("GET", BASE_URL)
    print("HEAD:", len(head.content), "GET:", len(get.content))

if __name__ == "__main__":
    run(main)
