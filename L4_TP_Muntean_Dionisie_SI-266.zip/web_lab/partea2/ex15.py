# Laborator Python Web — exercițiul 15
# Muntean Dionisie, SI-266

import time
import requests

ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


BASE_URL = 'https://cybercor.org'

def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 15."""
    lines = fetch(BASE_URL).text.splitlines()
    print("Linii:", len(lines))
    print("Lungime maximă:", len(max(lines, key=len, default="")))

if __name__ == "__main__":
    run(main)
