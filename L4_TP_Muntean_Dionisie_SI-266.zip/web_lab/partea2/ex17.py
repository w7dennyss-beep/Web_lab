# Laborator Python Web — exercițiul 17
# Muntean Dionisie, SI-266

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10


def fetch(url, timeout=10):
    """Descarcă pagina și returnează răspunsul."""
    time.sleep(1)
    return requests.get(url, timeout=timeout)

def run(action):
    """Rulează exercițiul și explică erorile de rețea fără traceback."""
    try:
        action()
    except (requests.RequestException, OSError, ValueError) as error:
        print(f'Exercițiul nu a putut fi finalizat: {error}')

def main():
    """Demonstrează soluția exercițiului 17."""
    response = fetch("http://cybercor.org")
    for item in response.history:
        print(item.status_code, item.url)
    print("URL final:", response.url)

if __name__ == "__main__":
    run(main)
